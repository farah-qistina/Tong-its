﻿partial class MainForm
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        cardDisplay = new Label();
        drawCardBtn = new Button();
        dropCardBtn = new Button();
        makeMeldBtn = new Button();
        callDrawBtn = new Button();
        label1 = new Label();
        label2 = new Label();
        label3 = new Label();
        flowLayoutPanel2 = new FlowLayoutPanel();
        flowLayoutPanel3 = new FlowLayoutPanel();
        flowLayoutPanel4 = new FlowLayoutPanel();
        SuspendLayout();
        // 
        // cardDisplay
        // 
        cardDisplay.Location = new Point(399, 320);
        cardDisplay.Name = "cardDisplay";
        cardDisplay.Size = new Size(200, 30);
        cardDisplay.TabIndex = 2;
        cardDisplay.Text = "Welcome to Tong-Its!";
        cardDisplay.Click += labelStatus_Click;
        // 
        // drawCardBtn
        // 
        drawCardBtn.Anchor = AnchorStyles.Top;
        drawCardBtn.Location = new Point(415, 630);
        drawCardBtn.Name = "drawCardBtn";
        drawCardBtn.Size = new Size(145, 35);
        drawCardBtn.TabIndex = 3;
        drawCardBtn.Text = "Draw Card";
        drawCardBtn.UseVisualStyleBackColor = true;
        drawCardBtn.Click += drawCardBtn_Click;
        // 
        // dropCardBtn
        // 
        dropCardBtn.Anchor = AnchorStyles.Top;
        dropCardBtn.Location = new Point(415, 590);
        dropCardBtn.Name = "dropCardBtn";
        dropCardBtn.Size = new Size(145, 35);
        dropCardBtn.TabIndex = 4;
        dropCardBtn.Text = "Drop Card";
        dropCardBtn.UseVisualStyleBackColor = true;
        // 
        // makeMeldBtn
        // 
        makeMeldBtn.Anchor = AnchorStyles.Top;
        makeMeldBtn.Location = new Point(415, 670);
        makeMeldBtn.Name = "makeMeldBtn";
        makeMeldBtn.Size = new Size(145, 35);
        makeMeldBtn.TabIndex = 5;
        makeMeldBtn.Text = "Make Meld";
        makeMeldBtn.UseVisualStyleBackColor = true;
        // 
        // callDrawBtn
        // 
        callDrawBtn.Anchor = AnchorStyles.Top;
        callDrawBtn.Location = new Point(415, 710);
        callDrawBtn.Name = "callDrawBtn";
        callDrawBtn.Size = new Size(145, 35);
        callDrawBtn.TabIndex = 6;
        callDrawBtn.Text = "Call Draw";
        callDrawBtn.UseVisualStyleBackColor = true;
        // 
        // label1
        // 
        label1.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        label1.AutoSize = true;
        label1.Location = new Point(714, 713);
        label1.Name = "label1";
        label1.Size = new Size(98, 32);
        label1.TabIndex = 8;
        label1.Text = "Player 2";
        label1.Click += label1_Click;
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Location = new Point(140, 713);
        label2.Name = "label2";
        label2.Size = new Size(98, 32);
        label2.TabIndex = 9;
        label2.Text = "Player 1";
        // 
        // label3
        // 
        label3.Anchor = AnchorStyles.Top;
        label3.AutoSize = true;
        label3.Location = new Point(447, 9);
        label3.Name = "label3";
        label3.Size = new Size(98, 32);
        label3.TabIndex = 10;
        label3.Text = "Player 3";
        // 
        // flowLayoutPanel2
        // 
        flowLayoutPanel2.Location = new Point(566, 590);
        flowLayoutPanel2.Name = "flowLayoutPanel2";
        flowLayoutPanel2.Size = new Size(400, 115);
        flowLayoutPanel2.TabIndex = 8;
        // 
        // flowLayoutPanel3
        // 
        flowLayoutPanel3.Location = new Point(0, 590);
        flowLayoutPanel3.Name = "flowLayoutPanel3";
        flowLayoutPanel3.Size = new Size(400, 115);
        flowLayoutPanel3.TabIndex = 9;
        // 
        // flowLayoutPanel4
        // 
        flowLayoutPanel4.Location = new Point(297, 44);
        flowLayoutPanel4.Name = "flowLayoutPanel4";
        flowLayoutPanel4.Size = new Size(400, 115);
        flowLayoutPanel4.TabIndex = 10;
        // 
        // MainForm
        // 
        BackColor = SystemColors.InactiveCaption;
        ClientSize = new Size(974, 754);
        Controls.Add(flowLayoutPanel4);
        Controls.Add(flowLayoutPanel3);
        Controls.Add(flowLayoutPanel2);
        Controls.Add(label3);
        Controls.Add(label2);
        Controls.Add(label1);
        Controls.Add(callDrawBtn);
        Controls.Add(makeMeldBtn);
        Controls.Add(dropCardBtn);
        Controls.Add(drawCardBtn);
        Controls.Add(cardDisplay);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        Name = "MainForm";
        Text = "Tong-Its Game";
        Load += MainForm_Load;
        ResumeLayout(false);
        PerformLayout();
    }

    private Button drawCardBtn;
    private Button dropCardBtn;
    private Button makeMeldBtn;
    private Button callDrawBtn;
    private Label label1;
    private Label label2;
    private Label label3;
    private FlowLayoutPanel flowLayoutPanel2;
    private FlowLayoutPanel flowLayoutPanel3;
    private FlowLayoutPanel flowLayoutPanel4;
}
