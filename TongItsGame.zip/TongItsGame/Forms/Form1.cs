using System;
using System.Drawing;
using System.Windows.Forms;

public partial class MainForm : Form
{
    private Button buttonShuffle;
    private Button buttonDeal;
    private Label cardDisplay;
    private Panel panelCards;

    // Create an instance of your Game class
    private Game game;

    public MainForm()
    {
        InitializeComponent();
        this.Size = new Size(800, 600); // Set the form size
        this.StartPosition = FormStartPosition.CenterScreen; // Center form on screen
        game = new Game();
        game.HandsUpdated += Game_HandsUpdated;
        drawCardBtn.Click += drawCardButton_Click;
    }

    private void Game_HandsUpdated(int currentPlayerIndex, List<Hand> hands)
    {
        // Use Invoke to ensure UI updates are performed on the UI thread
        this.Invoke((MethodInvoker)delegate
        {
            // Here you can update the UI based on the currentPlayerIndex and hands
            UpdateUIForHands(currentPlayerIndex, hands);
        });
    }

    public void UpdateUIForHands(int currentPlayerIndex, List<Hand> hands)
    {
        // Assuming flowLayoutPanel3 is where you want to display the current player's hand.
        flowLayoutPanel3.Controls.Clear();

        // Access the current player's hand.
        Hand currentHand = hands[currentPlayerIndex];

        foreach (var card in currentHand.GetAllCards())
        {
            // Construct the filename based on the card's properties.
            // This assumes your images are named like "AceOfSpades.jpg".
            // Adjust the format as necessary to match your actual filenames.
            string imageName = $"{card.FaceValue}Of{card.Suit}.jpg";
            string imagePath = Path.Combine(Application.StartupPath, "Images", imageName);

            PictureBox cardPictureBox = new PictureBox
            {
                Width = 71, // Set the appropriate size
                Height = 96,
                Margin = new Padding(5), // Adjust spacing between cards
                Image = Image.FromFile(imagePath), // Load the image
                SizeMode = PictureBoxSizeMode.StretchImage // Make sure the image fits nicely
            };

            // Add the PictureBox to the FlowLayoutPanel.
            flowLayoutPanel3.Controls.Add(cardPictureBox);
        }
    }

    private void drawCardButton_Click(object sender, EventArgs e)
    {
        // Call the DrawCard() method and display the result
        string card = game.DrawCard();
        // Assuming you have a Label or TextBox named cardDisplay
        cardDisplay.Text = card;
    }

    private void buttonShuffle_Click(object sender, EventArgs e)
    {
        // Add code to shuffle the deck
        cardDisplay.Text = "Deck shuffled!";
    }

    private void buttonDeal_Click(object sender, EventArgs e)
    {
        // Add code to deal cards to the hands
        cardDisplay.Text = "Cards dealt!";
    }

    private void labelStatus_Click(object sender, EventArgs e)
    {

    }

    private void MainForm_Load(object sender, EventArgs e)
    {

    }

    private void drawCardBtn_Click(object sender, EventArgs e)
    {

    }

    private void label1_Click(object sender, EventArgs e)
    {

    }
}