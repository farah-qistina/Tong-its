public enum Suit
{
    Hearts,
    Diamonds,
    Clubs,
    Spades
}

public enum FaceValue
{
    Ace = 1,
    Two,
    Three,
    Four,
    Five,
    Six,
    Seven,
    Eight,
    Nine,
    Ten,
    Jack,
    Queen,
    King
}